﻿using System;
using Assignment2;
namespace Application
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            // Call class
            BMI bmi1 = new BMI();

            // Get and set name. 
            Console.WriteLine("Please enter your first name: ");
            bmi1.FirstName = Console.ReadLine();
            Console.WriteLine("Please enter your last name: ");
            bmi1.LastName = Console.ReadLine();
            
            // Ask user for his/her height, and the input will be read.
            Console.WriteLine("Please enter your height in inches(in). ");
            bmi1.HEIGHT = Convert.ToInt32(Console.ReadLine());

            // Ask user for his/her weight and the input will be read.
            Console.WriteLine("Please enter your weight in pounds(lb). ");
            bmi1.WEIGHT = Convert.ToInt32(Console.ReadLine());

            // The user's input is added to the formula class where the formula will be calculated and returned.
            bmi1.Formula(bmi1.HEIGHT, bmi1.WEIGHT);

            // Output.
            bmi1.BMIResponse(bmi1.FirstName, bmi1.LastName);
        }
    }
}