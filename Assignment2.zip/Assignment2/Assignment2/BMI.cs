﻿using System;
namespace Assignment2
{
    public class BMI
    {
        public string FirstName
        {
            get;
            set;
        }
        public string LastName
        {
            get;
            set;
        }
        public int HEIGHT
        {
            get;
            set;
        }
        public int WEIGHT
        {
            get;
            set;
        }
        public double RESULTS
        {
            get;
            set;
        }
        public void BMIResponse(string FirstName, string LastName)
        {
            Console.WriteLine("\nHello " + FirstName + " " + LastName + ".");
            Console.WriteLine("Your height is: " + HEIGHT + "in.");
            Console.WriteLine("Your weight is: " + WEIGHT + "lb.");
            Console.WriteLine("Your BMI is: " + RESULTS + ".");
        }
        public double Formula(double HEIGHT, double WEIGHT)
        {
            return RESULTS = ((WEIGHT * (HEIGHT * HEIGHT)) / 703);
        }
    }
}